import json
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers='kafka-service:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

def publish_events(file_path='events.json'):
    with open(file_path) as f:
        for line in f:
            event = json.loads(line)
            producer.send('user_interactions', value=event)

if __name__ == "__main__":
    publish_events()