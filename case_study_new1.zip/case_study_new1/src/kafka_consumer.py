from pymongo import MongoClient
from kafka import KafkaConsumer
import json

consumer = KafkaConsumer(
    'user_interactions',
    bootstrap_servers='kafka-service:9092',
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)

mongo_client = MongoClient('mongodb://mongodb:27017/')
db = mongo_client['interaction_db']
user_agg = db['user_aggregates']
item_agg = db['item_aggregates']

user_counts = {}
item_counts = {}

for message in consumer:
    event = message.value
    user = event['user_id']
    item = event['item_id']

    user_counts[user] = user_counts.get(user, 0) + 1
    item_counts[item] = item_counts.get(item, 0) + 1

    user_agg.update_one(
        {'user_id': user},
        {'$set': {'average_interactions': user_counts[user]}},
        upsert=True
    )

    item_agg.update_one(
        {'item_id': item},
        {'$set': {
            'min_interactions': item_counts[item],
            'max_interactions': item_counts[item]
        }},
        upsert=True
    )