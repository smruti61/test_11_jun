import json
import random
import time
from faker import Faker

fake = Faker()

INTERACTION_TYPES = ['click', 'view', 'purchase']

def generate_event():
    return {
        'user_id': fake.uuid4(),
        'item_id': fake.uuid4(),
        'interaction_type': random.choice(INTERACTION_TYPES),
        'timestamp': fake.iso8601()
    }

def main(batch_size=100, interval=2):
    while True:
        events = [generate_event() for _ in range(batch_size)]
        with open('events.json', 'w') as f:
            for event in events:
                f.write(json.dumps(event) + '\n')
        time.sleep(interval)

if __name__ == "__main__":
    main()