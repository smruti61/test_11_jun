import streamlit as st
from pymongo import MongoClient

mongo_client = MongoClient('mongodb://localhost:27017/')
db = mongo_client['interaction_db']

st.title("Real-Time User Interaction Dashboard")

user_data = list(db['user_aggregates'].find())
item_data = list(db['item_aggregates'].find())

st.header("Average Interactions per User")
for user in user_data:
    st.write(f"User {user['user_id']}: {user['average_interactions']}")

st.header("Max/Min Interactions per Item")
for item in item_data:
    st.write(f"Item {item['item_id']}: Max {item['max_interactions']}, Min {item['min_interactions']}")