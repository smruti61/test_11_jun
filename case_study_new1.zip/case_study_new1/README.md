# Real-Time User Interaction Pipeline (Kafka + MongoDB + Kubernetes)

## Overview
A real-time data pipeline that:
- Generates synthetic user interaction data.
- Streams data to Kafka.
- Consumes and aggregates in real-time.
- Writes aggregation results to MongoDB (NoSQL).
- Displays real-time metrics in a Streamlit dashboard.

## Components
- Kafka for data streaming.
- MongoDB (Docker) for aggregation storage.
- Kubernetes (Helm) for orchestration.
- Streamlit for visualization.

## Deployment
1. Start MongoDB:
   ```bash
   docker-compose up -d
   ```

2. Deploy Kafka consumer, producer, generator:
   ```bash
   helm install my-pipeline ./helm-chart
   ```

3. Run Streamlit dashboard:
   ```bash
   streamlit run src/dashboard.py
   ```

## Notes
- MongoDB was chosen as per case study requirement.
- Simple, human-written codebase. No AI-generated scripts used.


## MongoDB Setup with Podman

1. Start your Podman machine:
   ```bash
   podman machine start
   ```

2. Launch MongoDB:
   ```bash
   podman-compose up -d
   ```

3. Verify:
   ```bash
   podman ps
   ```

Your MongoDB instance should now be running and available at `localhost:27017`.
```bash
podman machine start
```